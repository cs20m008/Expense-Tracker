package authservice.utils;

public class ValidationUtil
{
}
